Jeu de pendu javascript-----------------------
Url     : http://codes-sources.commentcamarche.net/source/45995-jeu-de-pendu-javascriptAuteur  : Mal_au_DOSDate    : 05/08/2013
Licence :
=========

Ce document intitul� � Jeu de pendu javascript � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Ceci est un petit jeu de pendu assez simple mais toujours agr&eacute;able. Il ut
ilise CSS pour masquer les lettres du mot &agrave; trouver.
<br />La descriptio
n devant faire plus de 100 caract&egrave;res je baratine un peu mais sinon il n'
y a rien de sp&eacute;cial &agrave; dire.
<br /><a name='source-exemple'></a><h
2> Source / Exemple : </h2>
<br /><pre class='code' data-mode='basic'>
/*
T�
l�charger le zip

<ul><li>/</li></ul>
</pre>
<br /><a name='conclusion'></a>
<h2> Conclusion : </h2>
<br />N'h&eacute;sitez pas &agrave; me faire part de v
os commentaires
