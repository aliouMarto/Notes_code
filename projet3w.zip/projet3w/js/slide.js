var i;
var index = 0;
var imgs = document.getElementsByClassName("images");

function slider(){
  //js, class have to add in loop. remove class active.
  for(i=0;i<imgs.length;i++){
    imgs[i].classList.remove("active"); 
  }
  index++;
  // set numbers class active not > class.lenght
  if(index>imgs.length){
    index=1;
  }
  //add class active (feature in css).
  imgs[index-1].classList.add("active");
  setTimeout(slider,4000);
}
slider();

